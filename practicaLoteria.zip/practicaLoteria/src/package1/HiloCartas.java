package package1;

import java.util.ArrayList;

public class HiloCartas extends Thread {

    String[] baraja = new String[51];
    ArrayList<String> pasadas = new ArrayList<>();
    String[] nombres = {"El gallo", "El diablo", "La dama", "El catrín", "El paraguas", "La sirena", "La escalera",
        "La botella", "El barril", "El árbol", "El melón", "El valiente", "El gorrito", "La muerte", "La pera",
        "La bandera", "El bandolón", "El violoncello", "La garza", "El pájaro", "La mano", "La bota", "La luba",
        "El cotorro", "El borracho", "El negrito", "El corazón", "La sandía", "El tambor", "El camarón",
        "Las jaras", "El músico", "La araña", "El soldado", "La estrella", "El cazo", "El mundo", "El apache",
        "El nopal", "El alacrán", "La rosa", "La calavera", "La campana", "El cantarito", "El venado", "El sol",
        "La corona", "La chalupa", "El pino", "El pescado", "La palma"};
    boolean gano;
    Ventana v;
    int contador = 0;
    int millis = 5000;

    public HiloCartas(Ventana v) {
        this.v = v;
        gano = false;
        llenarBaraja();
    }

    @Override
    public void run() {
        while (!pasaronTodas()) {

            v.mostrarCarta(baraja[contador]);
            pasarCartas(contador);
            contador++;

            try {
                sleep(millis);
            } catch (Exception e) {
            }

        }
    }

    private void llenarBaraja() {
        for (int i = 0; i < 51; i++) {
            baraja[(i)] = "src/cartas/"
                    + (i + 1) + ".png";
        }
    }

    private void pasarCartas(int contador) {
        pasadas.add(baraja[contador]);
    }

    private boolean pasaronTodas() {
        return pasadas.size() == 51;
    }

    public void gano() {
        gano = true;
        millis = 500;
        v.mostrarNombres(nombres, contador);
    }

}
