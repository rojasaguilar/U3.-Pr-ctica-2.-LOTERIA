package package1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class HiloCartas extends Thread {

    ArrayList<Integer> baraja = new ArrayList<>();
    ArrayList<Integer> pasadas = new ArrayList<>();

    String[] nombres = {"El gallo", "El diablo", "La dama", "El catrín", "El paraguas", "La sirena", "La escalera",
        "La botella", "El barril", "El árbol", "El melón", "El valiente", "El gorrito", "La muerte", "La pera",
        "La bandera", "El bandolón", "El violoncello", "La garza", "El pájaro", "La mano", "La bota", "La luba",
        "El cotorro", "El borracho", "El negrito", "El corazón", "La sandía", "El tambor", "El camarón",
        "Las jaras", "El músico", "La araña", "El soldado", "La estrella", "El cazo", "El mundo", "El apache",
        "El nopal", "El alacrán", "La rosa", "La calavera", "La campana", "El cantarito", "El venado", "El sol",
        "La corona", "La chalupa", "El pino", "El pescado", "La palma"};

    Map<Integer, String> map = new HashMap<Integer, String>();

    boolean gano;
    Ventana v;
    int contador = 0;
    int millis = 1000;

    public HiloCartas(Ventana v) {
        this.v = v;
        gano = false;
        llenarBaraja();
        IniciarDiccionario();
    }

    @Override
    public void run() {
        while (!pasaronTodas()) {
            if (pasadas.size() >= 16) {
                v.jButton1.setEnabled(true);
            }
            int carta = numeroCarta();
            if (!(pasadas.contains(carta))) {
                v.mostrarCarta("src/cartas/" + baraja.get(carta) + ".png");
                pasarCartas(carta);

                try {
                    sleep(millis);
                } catch (Exception e) {
                }

            }

        }
    }

    private void llenarBaraja() {
        for (int i = 1; i < 52; i++) {
            baraja.add(i);
        }
    }

    private void pasarCartas(int carta) {
        pasadas.add(baraja.get(carta));
        baraja.remove(carta);
    }

    private boolean pasaronTodas() {
        return baraja.isEmpty();
    }

    public void gano() {
        gano = true;
        millis = 500;
        v.mostrarNombres(textoCartasNoPasadas());
    }

    private int numeroCarta() {
        return new Random().nextInt(baraja.size());
    }

    private void IniciarDiccionario() {
        for (int i = 0; i < baraja.size(); i++) {
            map.put(i, nombres[i]);
        }
    }

    private String textoCartasNoPasadas() {
        String texto = "";
        for (Integer carta : baraja) {
            texto += map.get(carta) + "\n";
        }
        return texto;
    }

}
